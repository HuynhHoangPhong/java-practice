package Bai3;
public class NuocGiaiKhat extends HangHoa {
    private String donViTinh;
    private int soLuong;
    private double donGia;
    private static double tyLeChietKhau = 1.0;

    public NuocGiaiKhat(String maHang, String tenHang, String donViTinh, int soLuong, double donGia) {
        super(maHang, tenHang);
        if (donViTinh.equalsIgnoreCase("kết") || 
            donViTinh.equalsIgnoreCase("thùng") || 
            donViTinh.equalsIgnoreCase("chai") || 
            donViTinh.equalsIgnoreCase("lon")) {
            this.donViTinh = donViTinh;
        } else {
            this.donViTinh = "kết";
        }
        this.soLuong = soLuong;
        this.donGia = donGia;
    }

    public String getDonViTinh() {
        return donViTinh;
    }

    public void setDonViTinh(String donViTinh) {
        if (donViTinh.equalsIgnoreCase("kết") || 
            donViTinh.equalsIgnoreCase("thùng") || 
            donViTinh.equalsIgnoreCase("chai") || 
            donViTinh.equalsIgnoreCase("lon")) {
            this.donViTinh = donViTinh;
        } else {
            this.donViTinh = "kết";
        }
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public double getDonGia() {
        return donGia;
    }

    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }

    public static double getTyLeChietKhau() {
        return tyLeChietKhau;
    }

    public static void setTyLeChietKhau(double tyLeChietKhau) {
        NuocGiaiKhat.tyLeChietKhau = tyLeChietKhau;
    }

    public double tongTien() {
        double thanhTien = 0;
        if (donViTinh.equalsIgnoreCase("kết") || donViTinh.equalsIgnoreCase("thùng")) {
            thanhTien = soLuong * donGia;
        } else if (donViTinh.equalsIgnoreCase("chai")) {
            thanhTien = soLuong * donGia / 20;
        } else if (donViTinh.equalsIgnoreCase("lon")) {
            thanhTien = soLuong * donGia / 24;
        }
        return thanhTien * tyLeChietKhau;
    }

    public void xuat() {
        super.xuat();
        System.out.println("Don vi tinh: " + donViTinh);
         System.out.println("So luong: " + soLuong);
        System.out.println ("Don gia: " + donGia);
        System.out.println ("Tong tien: " + tongTien());

    }
    public static void main (String[]args)  {
        NuocGiaiKhat.setTyLeChietKhau(0.9);
        NuocGiaiKhat n1 = new NuocGiaiKhat("HH123", "Pepsi", "chai", 100, 200000);
        n1.xuat();
    }
}

