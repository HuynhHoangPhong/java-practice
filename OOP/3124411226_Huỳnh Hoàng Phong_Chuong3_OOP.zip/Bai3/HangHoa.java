package Bai3;
public class HangHoa {
    private String maHang;
    private String tenHang;

    public HangHoa() {
        this.maHang = "";
        this.tenHang = "";
    }

    public HangHoa(String maHang, String tenHang) {
        if (maHang != null && maHang.matches("^HH\\d{3}$")) {
            this.maHang = maHang;
        } else {
            this.maHang = "HH001";
        }
        this.tenHang = tenHang;
    }

    public String getMaHang() {
        return maHang;
    }

    public void setMaHang(String maHang) {
        if (maHang != null && maHang.matches("^HH\\d{3}$")) {
            this.maHang = maHang;
        } else {
            this.maHang = "HH001";
        }
    }

    public String getTenHang() {
        return tenHang;
    }

    public void setTenHang(String tenHang) {
        this.tenHang = tenHang;
    }

    public void xuat() {
        System.out.println("Ma hang: " + maHang);
        System.out.println("Ten hang: "+  tenHang);
    }
}


