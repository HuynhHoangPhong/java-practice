package Bai4;

public class nhanVien {
    private String MSNV;
    private String Name; 
    private double heSoLuong;


    public String getMSNV() {
        return MSNV;
    }
    public void setMSNV(String MSNV) {
        if (MSNV.startsWith("NV")){
            this.MSNV = MSNV;
        } else {
        this.MSNV = "NV001";
        }
    }
    public String getTen() {
        return Name;
    }
    public void setTen(String Name) {
        this.Name = Name;
    }
    public double getheSoLuong() {
        return heSoLuong;
    }
    public void setHeSoLuong(int heSoLuong) {
        this.heSoLuong = heSoLuong;
    }

    // constructer 
    public nhanVien() {
        this.MSNV = "NV01";
        this.Name = "Khong ton tai"; 
        this.heSoLuong = 2.34;
    }
    public nhanVien(String MSNV, String Name, int heSoLuong){
        this.MSNV = MSNV;
        this.Name = Name;
        this.heSoLuong = 1; 
    }

    public double thunhap(){
        int luongCoBan = 1150;
        return this.heSoLuong * luongCoBan;
    }
    public void xuat() {
        
        System.out.println("MSNV: " + this.MSNV);
        System.out.println("Ten: "+ this.Name);
        System.out.println("He so luong: "+ this.heSoLuong);
        System.out.println("Thu nhap: "+ thunhap());
    }
  
}
