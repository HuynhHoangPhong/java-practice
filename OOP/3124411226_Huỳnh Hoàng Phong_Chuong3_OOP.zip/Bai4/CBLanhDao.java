package Bai4;

public class CBLanhDao extends nhanVien {
    private String chucVu;
    private double thamNien;
    
    public String getchucVu() {
        return chucVu; 
    }
    public void setchucVu(String chucVu) {
    this.chucVu = chucVu;
    }

    public CBLanhDao() {
        super(); 
        this.chucVu = "Giam doc";
        this.thamNien = 10.0;
    }
    public CBLanhDao(String MSNV, String Name, int heSoLuong){
        super(MSNV, Name, heSoLuong);
        this.chucVu = chucVu;
        this.thamNien = thamNien;
    }
    
    public double hsLanhDao() {
       switch (chucVu.toLowerCase()) {
        case "Giam doc": return 7.0;
        case "Truong phong": return 6.0;
        case "Pho phong": return 4.5;
        default: return 1.0;
       }
    }

    public double phucapCB() {
        return 1500*hsLanhDao();
    }
    public double thunhapCB() {  
        return thunhap() + phucapCB();
    }
    public void xuatCB() {
        super.xuat();
        System.out.println("thu nhap can bo: "+ thunhapCB());
        System.out.println("Chuc vu: "+ this.chucVu);
    }

     public static void main (String[]args) {
        System.out.println("*****Thong tin nhan vien***** ");
        nhanVien nv1 = new nhanVien(); 
        nv1.xuat();
        System.out.println("******Thong tin can bo*****");
    
        CBLanhDao cb2 = new CBLanhDao();
        cb2.setMSNV("NV009");
        cb2.setTen("Dieu Hien");
        cb2.xuatCB();
    }
}
