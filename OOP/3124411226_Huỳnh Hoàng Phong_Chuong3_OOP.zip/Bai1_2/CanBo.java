
import java.time.Year;
import java.util.Scanner;

public class CanBo extends NhanVien {
    private String ChucVu;
    private String PhongBan;
    private double HeSoPhuCapLanhDao;

    public CanBo() {
        super();
        this.ChucVu = "Truong phong";
        this.PhongBan = "Hanh chinh";
        this.HeSoPhuCapLanhDao = 5.0;
    }

    public CanBo(String MSNV, String Name, int HeSoLuong, String ChucVu, double HeSoPhuCapLanhDao) {
        super(MSNV, Name, HeSoLuong);
        this.ChucVu = ChucVu;
        this.PhongBan = "Hanh chinh";
        this.HeSoPhuCapLanhDao = HeSoPhuCapLanhDao;
        this.setSoNgayNghi(1);
        this.setNamVaoLam(Year.now().getValue());
    }

    public CanBo(String MSNV, String Name, int HeSoLuong, int NamVaoLam, int SoNgayNghi, String ChucVu, String PhongBan, double HeSoPhuCapLanhDao) {
        super(MSNV, Name, HeSoLuong);
        this.setNamVaoLam(NamVaoLam);
        this.setSoNgayNghi(SoNgayNghi);
        this.ChucVu = ChucVu;
        this.PhongBan = PhongBan;
        this.HeSoPhuCapLanhDao = HeSoPhuCapLanhDao;
    }

    public String getChucVu() {
        return ChucVu;
    }

    public void setChucVu(String ChucVu) {
        this.ChucVu = ChucVu;
    }

    public String getPhongBan() {
        return PhongBan;
    }

    public void setPhongBan(String PhongBan) {
        this.PhongBan = PhongBan;
    }

    public double getHeSoPhuCapLanhDao() {
        return HeSoPhuCapLanhDao;
    }

    public void setHeSoPhuCapLanhDao(double HeSoPhuCapLanhDao) {
        this.HeSoPhuCapLanhDao = HeSoPhuCapLanhDao;
    }

    public String xepLoai() {
        return "A";
    }

    public double phuCapLanhDao() {
        return getLuongCoBan() * HeSoPhuCapLanhDao;
    }

    public double TinhLuong() {
        return getLuongCoBan() * heSoThiDua() + phuCapThamNien() + phuCapLanhDao();
    }

    public void input() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap ma so nhan vien: ");
        setMSNV(sc.nextLine());
        System.out.print("Nhap ten nhan vien: ");
        setName(sc.nextLine());
        System.out.print("Nhap he so luong: ");
        setLuongCoBan(sc.nextInt());
        System.out.print("Nhap nam vao lam: ");
        setNamVaoLam(sc.nextInt());
        System.out.print("Nhap so ngay nghi: ");
        setSoNgayNghi(sc.nextInt());
        sc.nextLine();
        System.out.print("Nhap chuc vu: ");
        ChucVu = sc.nextLine();
        System.out.print("Nhap phong ban: ");
        PhongBan = sc.nextLine();
        System.out.print("Nhap he so phu cap lanh dao: ");
        HeSoPhuCapLanhDao = sc.nextDouble();
    }

    public void output() {
        System.out.println("MSNV: " + getMSNV());
        System.out.println("Ten: " + getName());
        System.out.println("Nam vao lam: " + getNamVaoLam());
        System.out.println("So ngay nghi: " + getSoNgayNghi());
        System.out.println("Chuc vu: " + ChucVu);
        System.out.println("Phong ban: " + PhongBan);
        System.out.println("He so phu cap lanh dao: " + HeSoPhuCapLanhDao);
        System.out.println("Phu cap lanh dao: " + phuCapLanhDao());
        System.out.println("Xep loai: " + xepLoai());
        System.out.println("Luong: " + TinhLuong());
    }

    public static void main(String[] args) {
        CanBo cb1 = new CanBo();
        cb1.output();
        CanBo cb2 = new CanBo("001", "Nguyen Van A", 3, "Giam doc", 7.0);
        cb2.output();
    }
}
