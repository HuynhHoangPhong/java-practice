import java.time.Year;
import java.util.function.LongUnaryOperator;

public class NhanVien {
    private String MSNV; 
    private String Name; 
    private int NamVaoLam; 
    private int HeSoLuong = 1150;
    private int SoNgayNghi;
    private int LuongCoBan = 1150;

// get, set
public String getMSNV() {
    return MSNV;
}
public void setMSNV(String MSNV){
    this.MSNV = MSNV;
}
public String getName() {
    return Name;
}
public void setName(String Name) {
    this.Name = Name;
}
public int getNamVaoLam() {
    return NamVaoLam;
}
public void setNamVaoLam(int NamVaoLam) {
    this.NamVaoLam = NamVaoLam;
}
public int getLuongCoBan() {
    return LuongCoBan;
}
public void setLuongCoBan(int LuongCoBan){
    this.LuongCoBan =LuongCoBan;
}
public int getSoNgayNghi() {
    return SoNgayNghi;
}
public void setSoNgayNghi(int SoNgayNghi){
    this.SoNgayNghi=SoNgayNghi;
}



    // constructer
    public NhanVien(String MSNV, String name, int HeSoLuong) {
        this.MSNV = MSNV;
        this.Name = Name;
        this.HeSoLuong = HeSoLuong;
        this.NamVaoLam = Year.now().getValue();
        this.SoNgayNghi = 0;
    }
    public NhanVien() {
        this.MSNV = "000";
        this.Name = "khong ton tai";
        this.HeSoLuong = 1;
        this.NamVaoLam = Year.now().getValue();
        this.SoNgayNghi = 0;
    }
    // phuong thuc tinh phu cap tham nien
    public double phuCapThamNien() {
        int NamHienTai = Year.now().getValue();
        int SoNamLamViec = NamHienTai - NamVaoLam; 
        if (SoNamLamViec >= 5) {
            return SoNamLamViec*HeSoLuong/100;
        } else {
            return 0;
        }
    }
    //Xep loai 
   public String xepLoai() {
    if (SoNgayNghi <= 1){
     return "A";
   } else if (SoNgayNghi <=3) {
    return "B";
   } else {
    return "C";
   }
}
// he so thi thua 
public double heSoThiDua(){
    switch(xepLoai()){
        case "A" :return 1.0;
        case "B" :return 0.75;
        default: return 0.5;
    }
}

// tinh luong
public double TinhLuong() {
    return LuongCoBan*HeSoLuong*heSoThiDua()+phuCapThamNien();
}
// 
public void output() {
    System.out.println ("MSNV: " +this.MSNV);
    System.out.println ("Ten nhan vien: " + this.Name);
    System.out.println ("So Ngay Nghi: " + this.SoNgayNghi);
    System.out.println ("Xep loai: " + this.xepLoai());
    System.out.println ("He so thi dua: " + this.heSoThiDua());
    System.out.println ("Luong thuong tham nien: " +this.phuCapThamNien());
    System.out.println ("Luong: "+ this.TinhLuong());

}

//main 
public static void main (String[]args) {
    NhanVien nv1 = new NhanVien(); 
    nv1.setName("Nguyen van teo");
    nv1.setMSNV("12345");
    nv1.setNamVaoLam(2024);
    nv1.setLuongCoBan(1150);
    nv1.setSoNgayNghi(2);
    nv1.output();

}

}
 


