package Bai5;

public class sinhVien extends nguoi {
    private String MSSV;
    private String heDaoTao;
    private int tongTin;

    public String getMSSV() {
        return MSSV;
    }
    public void setMSSV(String MSSV) {
        this.MSSV = MSSV; 
    } 
    public String getheDaoTao() {
        return heDaoTao;
    }
    public void setheDaoTao(String heDaoTao) {
        if (heDaoTao.equalsIgnoreCase("Dai hoc")||heDaoTao.equalsIgnoreCase("Cao dang")||heDaoTao.equalsIgnoreCase("Cao dang nghe")) {
            this.heDaoTao = heDaoTao;
        } else this.heDaoTao = "Dai hoc"; 
    }
    public int gettongTin() {
        return tongTin;
    }
    public void settongTin(int tongTin){
        this.tongTin = tongTin; 
    }
    // 
    public sinhVien(String Name, String gioiTinh, String NgaySinh, String MSSV, String heDaoTao ) {
        super();
        this.MSSV = MSSV;
        this.heDaoTao =heDaoTao; 
        this.tongTin = soTin();  
    }
    
    //
    public int soTin(){
        switch(heDaoTao.toLowerCase()) {
            case "Dai hoc": return  150;
            case "Cao dang": return 100;
            case "Cao dang nghe": return 130;
            default: return 150;
        }
    }
    public double motChi() {
        switch(heDaoTao.toLowerCase()) {
            case "Dai hoc": return 200.000;
            case "Cao dang": return 150.000;
            case "Cao dang nghe": return 120.000;
            default: return 200.000;
        }
    }
    // 
    public double hocPhi() {
        return soTin()*motChi();
    }
    // 
    public void xuatSV() {
        System.out.println ("***Thong tin sinh vien***");
        super.xuat();
        System.out.println("MSSV: " + this.MSSV);
        System.out.println("He dao tao: " + this.heDaoTao);
        System.out.println ("Tong tin: "+ soTin()  );
        System.out.println("Hoc phi: "+ this.hocPhi() + " VND");

    }

    public static void main (String[]args){
        sinhVien sv1 = new sinhVien("Teo", "Nam", "01-01-2006", "009", "Dai hoc");
        sv1.xuatSV(); 
    }

}
