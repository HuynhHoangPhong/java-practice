package Bai5;

import java.time.format.DateTimeFormatter;

public class nguoi {
    private String Name; 
    private String NgaySinh;
    private String GioiTinh; 

    public String getName() {
        return Name; 
    }
    public void setName(String Name) {
        this.Name = Name;
    }
    public String getNgaySinh() {
        return NgaySinh;
    }
    public void setNgaySinh(String NgaySinh) {
        DateTimeFormatter dt = DateTimeFormatter.ofPattern("dd-mm-yyyy");
        this.NgaySinh = NgaySinh;
    }
    public String getGioiTinh() {
        return GioiTinh;
    }
    public void setGioiTinh(String GioiTinh){
       if (GioiTinh.equalsIgnoreCase("Nam") || GioiTinh.equalsIgnoreCase("Nu")) {
        this.GioiTinh = GioiTinh;
       } else this.GioiTinh = "Nam";
    }
    // 
    public nguoi(){
        this.Name = "Koko"; 
        this.GioiTinh = "Nam"; 
        this.NgaySinh = "01-01-2006";
    }
    public nguoi(String Name, String NgaySinh, String GioiTinh) {
        this.Name = Name; 
        this.GioiTinh = GioiTinh;
        this.NgaySinh = NgaySinh;
    }
    public void xuat() {
        System.out.println("Ten: "+ this.Name);
        System.out.println("Gioi tinh: "+ this.GioiTinh);
        System.out.println("Ngay sinh: "+ this.NgaySinh); 
    }
    
}
